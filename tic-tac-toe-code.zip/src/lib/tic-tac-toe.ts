export type Cell = "X" | "O" | null;
export type Board = Cell[];

export const WIN_LINES: number[][] = [
  [0, 1, 2], [3, 4, 5], [6, 7, 8],
  [0, 3, 6], [1, 4, 7], [2, 5, 8],
  [0, 4, 8], [2, 4, 6],
];

export function checkWinner(board: Board): { winner: Cell; line: number[] | null } {
  for (const line of WIN_LINES) {
    const [a, b, c] = line;
    if (board[a] && board[a] === board[b] && board[a] === board[c]) {
      return { winner: board[a], line };
    }
  }
  return { winner: null, line: null };
}

export function isDraw(board: Board): boolean {
  return board.every((c) => c !== null) && !checkWinner(board).winner;
}

export function emptyIndices(board: Board): number[] {
  return board.reduce<number[]>((acc, c, i) => (c === null ? [...acc, i] : acc), []);
}

function minimax(board: Board, player: "X" | "O", ai: "X" | "O"): { score: number; index: number } {
  const { winner } = checkWinner(board);
  if (winner === ai) return { score: 10, index: -1 };
  if (winner && winner !== ai) return { score: -10, index: -1 };
  if (isDraw(board)) return { score: 0, index: -1 };

  const moves: { score: number; index: number }[] = [];
  for (const i of emptyIndices(board)) {
    const newBoard = [...board];
    newBoard[i] = player;
    const result = minimax(newBoard, player === "X" ? "O" : "X", ai);
    moves.push({ score: result.score, index: i });
  }

  if (player === ai) {
    return moves.reduce((best, m) => (m.score > best.score ? m : best));
  } else {
    return moves.reduce((best, m) => (m.score < best.score ? m : best));
  }
}

export function getAIMove(board: Board, ai: "X" | "O", difficulty: "easy" | "medium" | "hard"): number {
  const empty = emptyIndices(board);
  if (empty.length === 0) return -1;

  if (difficulty === "easy") {
    return empty[Math.floor(Math.random() * empty.length)];
  }
  if (difficulty === "medium") {
    if (Math.random() < 0.5) return empty[Math.floor(Math.random() * empty.length)];
    return minimax(board, ai, ai).index;
  }
  return minimax(board, ai, ai).index;
}
