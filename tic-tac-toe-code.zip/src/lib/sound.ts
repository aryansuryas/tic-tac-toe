let ctx: AudioContext | null = null;
let enabled = true;

function getCtx() {
  if (typeof window === "undefined") return null;
  if (!ctx) {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    ctx = new AC();
  }
  return ctx;
}

export function setSoundEnabled(v: boolean) { enabled = v; }
export function isSoundEnabled() { return enabled; }

function tone(freq: number, duration: number, type: OscillatorType = "sine", gain = 0.08, delay = 0) {
  if (!enabled) return;
  const c = getCtx();
  if (!c) return;
  const t = c.currentTime + delay;
  const osc = c.createOscillator();
  const g = c.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, t);
  g.gain.setValueAtTime(0, t);
  g.gain.linearRampToValueAtTime(gain, t + 0.01);
  g.gain.exponentialRampToValueAtTime(0.0001, t + duration);
  osc.connect(g);
  g.connect(c.destination);
  osc.start(t);
  osc.stop(t + duration + 0.05);
}

export const sfx = {
  click: () => tone(520, 0.08, "triangle", 0.06),
  place: () => { tone(620, 0.1, "sine", 0.07); tone(880, 0.08, "sine", 0.05, 0.05); },
  win: () => {
    [523, 659, 784, 1046].forEach((f, i) => tone(f, 0.25, "triangle", 0.09, i * 0.1));
  },
  draw: () => { tone(300, 0.2, "sawtooth", 0.05); tone(220, 0.3, "sawtooth", 0.05, 0.15); },
  lose: () => { tone(330, 0.2, "sawtooth", 0.06); tone(220, 0.4, "sawtooth", 0.06, 0.15); },
};
