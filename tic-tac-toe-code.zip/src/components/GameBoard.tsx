import { useEffect, useMemo, useRef, useState } from "react";
import { Board, checkWinner, getAIMove, isDraw } from "@/lib/tic-tac-toe";
import { sfx } from "@/lib/sound";
import { Confetti } from "./Confetti";

type Mode = { kind: "friend" } | { kind: "ai"; difficulty: "easy" | "medium" | "hard" };

interface Score { x: number; o: number; draws: number; }
interface HistoryEntry { id: number; winner: "X" | "O" | "Draw"; pX: string; pO: string; mode: string; at: string; }

interface Props {
  mode: Mode;
  playerX: string;
  playerO: string;
  timerSeconds: number; // 0 = off
  onExit: () => void;
}

const LINE_COORDS: Record<string, { x1: string; y1: string; x2: string; y2: string }> = {
  "0,1,2": { x1: "5%", y1: "16.66%", x2: "95%", y2: "16.66%" },
  "3,4,5": { x1: "5%", y1: "50%", x2: "95%", y2: "50%" },
  "6,7,8": { x1: "5%", y1: "83.33%", x2: "95%", y2: "83.33%" },
  "0,3,6": { x1: "16.66%", y1: "5%", x2: "16.66%", y2: "95%" },
  "1,4,7": { x1: "50%", y1: "5%", x2: "50%", y2: "95%" },
  "2,5,8": { x1: "83.33%", y1: "5%", x2: "83.33%", y2: "95%" },
  "0,4,8": { x1: "8%", y1: "8%", x2: "92%", y2: "92%" },
  "2,4,6": { x1: "92%", y1: "8%", x2: "8%", y2: "92%" },
};

const EMPTY: Board = Array(9).fill(null);

export function GameBoard({ mode, playerX, playerO, timerSeconds, onExit }: Props) {
  const [board, setBoard] = useState<Board>(EMPTY);
  const [turn, setTurn] = useState<"X" | "O">("X");
  const [score, setScore] = useState<Score>({ x: 0, o: 0, draws: 0 });
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [timeLeft, setTimeLeft] = useState(timerSeconds);
  const [showPopup, setShowPopup] = useState<{ winner: "X" | "O" | "Draw"; line: number[] | null } | null>(null);
  const cellRefs = useRef<(HTMLButtonElement | null)[]>([]);

  const { winner, line } = useMemo(() => checkWinner(board), [board]);
  const draw = useMemo(() => isDraw(board), [board]);
  const gameOver = !!winner || draw;

  const aiTurn = mode.kind === "ai" && turn === "O" && !gameOver;
  const isHumanTurn = !gameOver && !aiTurn;

  // Handle game end
  useEffect(() => {
    if (!gameOver || showPopup) return;
    const w: "X" | "O" | "Draw" = winner ?? "Draw";
    setScore((s) => ({
      x: s.x + (w === "X" ? 1 : 0),
      o: s.o + (w === "O" ? 1 : 0),
      draws: s.draws + (w === "Draw" ? 1 : 0),
    }));
    setHistory((h) => [
      { id: Date.now(), winner: w, pX: playerX, pO: playerO, mode: mode.kind === "ai" ? `AI · ${mode.difficulty}` : "Friend", at: new Date().toLocaleTimeString() },
      ...h,
    ].slice(0, 10));
    if (w === "Draw") sfx.draw(); else sfx.win();
    const t = setTimeout(() => setShowPopup({ winner: w, line }), 700);
    return () => clearTimeout(t);
  }, [gameOver, winner, line, playerX, playerO, mode, showPopup]);

  // AI move
  useEffect(() => {
    if (!aiTurn) return;
    const t = setTimeout(() => {
      const idx = getAIMove(board, "O", mode.kind === "ai" ? mode.difficulty : "hard");
      if (idx >= 0) place(idx, "O");
    }, 450);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [aiTurn, board]);

  // Move timer
  useEffect(() => {
    if (timerSeconds === 0 || gameOver || aiTurn) return;
    setTimeLeft(timerSeconds);
    const interval = setInterval(() => {
      setTimeLeft((t) => {
        if (t <= 1) {
          // Auto-pass turn
          clearInterval(interval);
          setTurn((cur) => (cur === "X" ? "O" : "X"));
          return timerSeconds;
        }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [turn, gameOver, timerSeconds, aiTurn]);

  function place(i: number, who: "X" | "O") {
    setBoard((b) => {
      if (b[i] || checkWinner(b).winner) return b;
      const nb = [...b];
      nb[i] = who;
      sfx.place();
      return nb;
    });
    setTurn(who === "X" ? "O" : "X");
  }

  function handleCell(i: number) {
    if (!isHumanTurn || board[i]) return;
    place(i, turn);
  }

  function reset(full = false) {
    setBoard(EMPTY);
    setTurn("X");
    setShowPopup(null);
    setTimeLeft(timerSeconds);
    if (full) {
      setScore({ x: 0, o: 0, draws: 0 });
      setHistory([]);
    }
    sfx.click();
  }

  // Keyboard
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key >= "1" && e.key <= "9") {
        handleCell(parseInt(e.key) - 1);
      } else if (e.key.toLowerCase() === "r") {
        reset();
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [board, turn, gameOver]);

  const currentName = turn === "X" ? playerX : (mode.kind === "ai" ? "AI" : playerO);

  return (
    <div className="relative z-10 mx-auto grid w-full max-w-6xl gap-6 px-4 py-8 lg:grid-cols-[1fr_320px]">
      <Confetti show={!!showPopup && showPopup.winner !== "Draw"} />

      <div className="flex flex-col gap-6">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <button
            onClick={onExit}
            className="btn-ghost-glass rounded-full px-4 py-2 text-sm font-medium"
          >
            ← Menu
          </button>
          <div className="glass rounded-full px-5 py-2 text-sm">
            <span className="text-muted-foreground">Mode:</span>{" "}
            <span className="font-semibold">
              {mode.kind === "ai" ? `vs AI · ${mode.difficulty}` : "vs Friend"}
            </span>
          </div>
          <button
            onClick={() => reset(true)}
            className="btn-ghost-glass rounded-full px-4 py-2 text-sm font-medium"
          >
            Reset all
          </button>
        </div>

        {/* Scoreboard */}
        <div className="glass grid grid-cols-3 overflow-hidden rounded-2xl">
          <PlayerScore name={playerX} symbol="X" score={score.x} active={turn === "X" && !gameOver} color="x" />
          <div className="flex flex-col items-center justify-center border-x border-[var(--glass-border)] py-4">
            <div className="text-xs uppercase tracking-widest text-muted-foreground">Draws</div>
            <div className="text-3xl font-bold">{score.draws}</div>
          </div>
          <PlayerScore name={mode.kind === "ai" ? "AI" : playerO} symbol="O" score={score.o} active={turn === "O" && !gameOver} color="o" />
        </div>

        {/* Turn indicator + timer */}
        <div className="flex items-center justify-between rounded-xl">
          <div className="flex items-center gap-3">
            <span className={`inline-block size-3 rounded-full ${turn === "X" ? "bg-[var(--x-color)]" : "bg-[var(--o-color)]"} pulse-glow`} />
            <span className="text-sm">
              {gameOver ? "Round complete" : <><span className="font-semibold">{currentName}</span>'s turn ({turn})</>}
            </span>
          </div>
          {timerSeconds > 0 && !gameOver && !aiTurn && (
            <div className="glass rounded-full px-3 py-1 text-sm tabular-nums">
              ⏱ {timeLeft}s
            </div>
          )}
        </div>

        {/* Board */}
        <div className="relative mx-auto aspect-square w-full max-w-[min(90vw,520px)]">
          <div className="glass-strong absolute inset-0 rounded-3xl" />
          <div className="relative grid h-full w-full grid-cols-3 grid-rows-3 gap-3 p-3">
            {board.map((cell, i) => (
              <button
                key={i}
                ref={(el) => { cellRefs.current[i] = el; }}
                onClick={() => handleCell(i)}
                disabled={!isHumanTurn || !!cell}
                aria-label={`Cell ${i + 1}${cell ? `, ${cell}` : ", empty"}`}
                className={`group relative flex items-center justify-center rounded-2xl border border-[var(--glass-border)] bg-[var(--glass-bg)] backdrop-blur-md transition-all duration-200 ${
                  !cell && isHumanTurn ? "hover:scale-[1.03] hover:bg-white/10 cursor-pointer" : "cursor-default"
                } ${line?.includes(i) ? "ring-2 ring-[var(--color-primary)]" : ""}`}
              >
                {cell && (
                  <span
                    className={`animate-pop text-6xl font-black sm:text-7xl ${
                      cell === "X" ? "text-[var(--x-color)]" : "text-[var(--o-color)]"
                    }`}
                    style={{ textShadow: "0 0 30px currentColor" }}
                  >
                    {cell}
                  </span>
                )}
                {!cell && isHumanTurn && (
                  <span className="absolute inset-0 flex items-center justify-center text-5xl font-black opacity-0 transition-opacity group-hover:opacity-20">
                    {turn}
                  </span>
                )}
              </button>
            ))}
          </div>

          {line && (
            <svg className="pointer-events-none absolute inset-0 h-full w-full" preserveAspectRatio="none">
              <line
                {...LINE_COORDS[line.join(",")]}
                className="win-line"
                stroke="var(--color-primary)"
                strokeWidth="6"
                strokeLinecap="round"
                style={{ filter: "drop-shadow(0 0 8px var(--color-primary))" }}
              />
            </svg>
          )}
        </div>

        <div className="text-center text-xs text-muted-foreground">
          Tip: use keys <kbd className="rounded bg-white/10 px-1">1–9</kbd> to play, <kbd className="rounded bg-white/10 px-1">R</kbd> to restart
        </div>
      </div>

      {/* Sidebar: match history */}
      <aside className="glass h-fit rounded-2xl p-5">
        <h3 className="mb-3 text-sm font-semibold uppercase tracking-widest text-muted-foreground">Match history</h3>
        {history.length === 0 ? (
          <p className="text-sm text-muted-foreground">No matches yet — play your first round!</p>
        ) : (
          <ul className="space-y-2">
            {history.map((h) => (
              <li key={h.id} className="flex items-center justify-between rounded-lg bg-white/5 px-3 py-2 text-sm fade-up">
                <div>
                  <div className="font-medium">
                    {h.winner === "Draw" ? "Draw" : `${h.winner === "X" ? h.pX : h.pO} won`}
                  </div>
                  <div className="text-xs text-muted-foreground">{h.mode} · {h.at}</div>
                </div>
                <span className={`text-lg font-bold ${h.winner === "X" ? "text-[var(--x-color)]" : h.winner === "O" ? "text-[var(--o-color)]" : "text-muted-foreground"}`}>
                  {h.winner === "Draw" ? "–" : h.winner}
                </span>
              </li>
            ))}
          </ul>
        )}
      </aside>

      {/* Game over popup */}
      {showPopup && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm fade-up">
          <div className="glass-strong mx-4 w-full max-w-md rounded-3xl p-8 text-center animate-pop">
            <div className="text-sm uppercase tracking-widest text-muted-foreground">
              {showPopup.winner === "Draw" ? "It's a tie" : "Victory"}
            </div>
            <h2 className="mt-2 text-4xl font-black gradient-text">
              {showPopup.winner === "Draw"
                ? "Draw!"
                : `${showPopup.winner === "X" ? playerX : (mode.kind === "ai" ? "AI" : playerO)} wins!`}
            </h2>
            <p className="mt-3 text-muted-foreground">
              {showPopup.winner === "Draw"
                ? "Evenly matched. Care for a rematch?"
                : "A flawless line. Run it back?"}
            </p>
            <div className="mt-6 flex flex-wrap justify-center gap-3">
              <button onClick={() => reset(false)} className="btn-primary rounded-full px-6 py-3 font-semibold">
                Play again
              </button>
              <button onClick={onExit} className="btn-ghost-glass rounded-full px-6 py-3 font-semibold">
                Back to menu
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function PlayerScore({ name, symbol, score, active, color }: { name: string; symbol: "X" | "O"; score: number; active: boolean; color: "x" | "o" }) {
  return (
    <div className={`flex flex-col items-center justify-center py-4 transition-all ${active ? "bg-white/5" : ""}`}>
      <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-muted-foreground">
        <span className={`text-lg font-black ${color === "x" ? "text-[var(--x-color)]" : "text-[var(--o-color)]"}`}>{symbol}</span>
        <span className="max-w-[100px] truncate">{name}</span>
      </div>
      <div className="text-3xl font-bold">{score}</div>
    </div>
  );
}
