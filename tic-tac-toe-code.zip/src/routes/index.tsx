import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { GameBoard } from "@/components/GameBoard";
import { isSoundEnabled, setSoundEnabled, sfx } from "@/lib/sound";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Nova TicTacToe — Premium Modern Tic Tac Toe Game" },
      { name: "description", content: "Play a beautiful, modern Tic Tac Toe game online. Two-player or vs AI (Easy, Medium, Unbeatable). Glassmorphism design, animations, scoreboard, and more." },
      { property: "og:title", content: "Nova TicTacToe — Premium Modern Tic Tac Toe" },
      { property: "og:description", content: "A premium Tic Tac Toe web game with AI difficulty modes, scoreboard, animations and a stunning glassmorphism UI." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Home,
});

type Mode = { kind: "friend" } | { kind: "ai"; difficulty: "easy" | "medium" | "hard" };
type Screen = "menu" | "game" | "settings" | "about";

function Home() {
  const [screen, setScreen] = useState<Screen>("menu");
  const [theme, setTheme] = useState<"dark" | "light">("dark");
  const [sound, setSound] = useState(true);
  const [timer, setTimer] = useState(0);
  const [playerX, setPlayerX] = useState("Player 1");
  const [playerO, setPlayerO] = useState("Player 2");
  const [mode, setMode] = useState<Mode>({ kind: "friend" });

  useEffect(() => {
    document.documentElement.classList.toggle("light", theme === "light");
  }, [theme]);

  useEffect(() => { setSoundEnabled(sound); }, [sound]);
  useEffect(() => { setSound(isSoundEnabled()); }, []);

  function start(m: Mode) {
    sfx.click();
    setMode(m);
    setScreen("game");
  }

  return (
    <div className="bg-orbs relative min-h-screen">
      {/* Top nav */}
      <header className="relative z-20 mx-auto flex max-w-6xl items-center justify-between px-4 py-5">
        <button onClick={() => setScreen("menu")} className="flex items-center gap-2 text-lg font-black tracking-tight">
          <span className="grid size-8 place-items-center rounded-lg" style={{ background: "var(--gradient-primary)" }}>
            <span className="text-sm font-black text-black">N</span>
          </span>
          <span className="gradient-text">Nova<span className="text-foreground">TTT</span></span>
        </button>
        <nav className="flex items-center gap-2">
          <button onClick={() => setScreen("about")} className="btn-ghost-glass rounded-full px-4 py-2 text-sm">About</button>
          <button onClick={() => setScreen("settings")} className="btn-ghost-glass rounded-full px-4 py-2 text-sm">Settings</button>
          <button
            onClick={() => { setTheme(theme === "dark" ? "light" : "dark"); sfx.click(); }}
            aria-label="Toggle theme"
            className="btn-ghost-glass grid size-9 place-items-center rounded-full"
          >
            {theme === "dark" ? "☀️" : "🌙"}
          </button>
        </nav>
      </header>

      {screen === "menu" && (
        <Landing onStart={start} playerX={playerX} playerO={playerO} setPlayerX={setPlayerX} setPlayerO={setPlayerO} />
      )}
      {screen === "game" && (
        <GameBoard mode={mode} playerX={playerX} playerO={playerO} timerSeconds={timer} onExit={() => setScreen("menu")} />
      )}
      {screen === "settings" && (
        <Settings
          sound={sound} setSound={setSound}
          theme={theme} setTheme={setTheme}
          timer={timer} setTimer={setTimer}
          onBack={() => setScreen("menu")}
        />
      )}
      {screen === "about" && <About onBack={() => setScreen("menu")} />}

      <Footer />
    </div>
  );
}

function Landing({ onStart, playerX, playerO, setPlayerX, setPlayerO }: {
  onStart: (m: Mode) => void;
  playerX: string; playerO: string;
  setPlayerX: (v: string) => void; setPlayerO: (v: string) => void;
}) {
  const [showAi, setShowAi] = useState(false);

  return (
    <main className="relative z-10 mx-auto max-w-6xl px-4 pb-12 pt-6">
      <section className="grid items-center gap-10 py-10 lg:grid-cols-2 lg:py-16">
        <div className="fade-up">
          <span className="glass inline-flex items-center gap-2 rounded-full px-3 py-1 text-xs uppercase tracking-widest text-muted-foreground">
            <span className="size-1.5 rounded-full bg-[var(--color-accent)]" /> v1 · No login · Plays offline
          </span>
          <h1 className="mt-4 text-5xl font-black leading-[1.05] tracking-tight sm:text-6xl lg:text-7xl">
            The classic, <br />
            <span className="gradient-text">reimagined.</span>
          </h1>
          <p className="mt-5 max-w-lg text-lg text-muted-foreground">
            A premium Tic Tac Toe experience — glass surfaces, fluid motion, and an unbeatable AI when you're ready for a real challenge.
          </p>

          <div className="mt-8 flex flex-wrap gap-3">
            <button
              onClick={() => onStart({ kind: "friend" })}
              className="btn-primary rounded-full px-7 py-3.5 text-base font-semibold"
            >
              Play vs Friend
            </button>
            <button
              onClick={() => setShowAi((v) => !v)}
              className="btn-ghost-glass rounded-full px-7 py-3.5 text-base font-semibold"
            >
              Play vs AI {showAi ? "▲" : "▼"}
            </button>
          </div>

          {showAi && (
            <div className="fade-up mt-4 flex flex-wrap gap-2">
              {(["easy", "medium", "hard"] as const).map((d) => (
                <button
                  key={d}
                  onClick={() => onStart({ kind: "ai", difficulty: d })}
                  className="glass rounded-full px-5 py-2.5 text-sm font-medium capitalize transition hover:scale-105"
                >
                  {d === "hard" ? "Unbeatable" : d}
                </button>
              ))}
            </div>
          )}

          <div className="mt-8 grid max-w-md gap-3 sm:grid-cols-2">
            <NameInput label="Player X" value={playerX} onChange={setPlayerX} accent="x" />
            <NameInput label="Player O" value={playerO} onChange={setPlayerO} accent="o" />
          </div>
        </div>

        {/* Decorative preview board */}
        <div className="relative mx-auto aspect-square w-full max-w-md fade-up">
          <div className="glass-strong absolute inset-0 rounded-3xl" />
          <div className="relative grid h-full w-full grid-cols-3 grid-rows-3 gap-3 p-3">
            {["X", "", "O", "", "X", "", "O", "", "X"].map((c, i) => (
              <div key={i} className="flex items-center justify-center rounded-2xl border border-[var(--glass-border)] bg-white/5">
                {c && (
                  <span
                    className={`text-5xl font-black sm:text-6xl ${c === "X" ? "text-[var(--x-color)]" : "text-[var(--o-color)]"}`}
                    style={{ textShadow: "0 0 24px currentColor" }}
                  >
                    {c}
                  </span>
                )}
              </div>
            ))}
          </div>
          <svg className="pointer-events-none absolute inset-0 h-full w-full" preserveAspectRatio="none">
            <line x1="8%" y1="8%" x2="92%" y2="92%" stroke="var(--color-primary)" strokeWidth="6" strokeLinecap="round" className="win-line" style={{ filter: "drop-shadow(0 0 8px var(--color-primary))" }} />
          </svg>
        </div>
      </section>

      {/* Features */}
      <section className="grid gap-4 py-10 sm:grid-cols-2 lg:grid-cols-4">
        {[
          { t: "Unbeatable AI", d: "Minimax-powered hard mode. Easy & medium for casual play." },
          { t: "Two-player mode", d: "Play side-by-side with a friend on any device." },
          { t: "Smart scoreboard", d: "Wins, losses, draws, and a rolling match history." },
          { t: "Beautiful motion", d: "Subtle glass, glow lines, confetti — no clutter." },
        ].map((f) => (
          <div key={f.t} className="glass rounded-2xl p-5 fade-up">
            <h3 className="text-base font-semibold">{f.t}</h3>
            <p className="mt-1 text-sm text-muted-foreground">{f.d}</p>
          </div>
        ))}
      </section>
    </main>
  );
}

function NameInput({ label, value, onChange, accent }: { label: string; value: string; onChange: (v: string) => void; accent: "x" | "o" }) {
  return (
    <label className="glass flex items-center gap-2 rounded-xl px-3 py-2.5">
      <span className={`text-lg font-black ${accent === "x" ? "text-[var(--x-color)]" : "text-[var(--o-color)]"}`}>
        {accent === "x" ? "X" : "O"}
      </span>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        maxLength={20}
        placeholder={label}
        aria-label={label}
        className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
      />
    </label>
  );
}

function Settings({ sound, setSound, theme, setTheme, timer, setTimer, onBack }: {
  sound: boolean; setSound: (v: boolean) => void;
  theme: "dark" | "light"; setTheme: (v: "dark" | "light") => void;
  timer: number; setTimer: (v: number) => void;
  onBack: () => void;
}) {
  return (
    <main className="relative z-10 mx-auto max-w-2xl px-4 py-10">
      <button onClick={onBack} className="btn-ghost-glass mb-6 rounded-full px-4 py-2 text-sm">← Back</button>
      <h2 className="text-4xl font-black gradient-text">Settings</h2>
      <div className="mt-6 space-y-3">
        <Row label="Sound effects" desc="Subtle clicks, wins, and draws">
          <Toggle on={sound} onChange={setSound} />
        </Row>
        <Row label="Theme" desc="Dark glass or daylight glass">
          <div className="flex gap-2">
            {(["dark", "light"] as const).map((t) => (
              <button
                key={t}
                onClick={() => setTheme(t)}
                className={`rounded-full px-4 py-1.5 text-sm capitalize transition ${
                  theme === t ? "btn-primary" : "btn-ghost-glass"
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </Row>
        <Row label="Timer per move" desc="Auto-pass turn when time runs out">
          <div className="flex flex-wrap gap-2">
            {[0, 5, 10, 20].map((s) => (
              <button
                key={s}
                onClick={() => setTimer(s)}
                className={`rounded-full px-4 py-1.5 text-sm transition ${
                  timer === s ? "btn-primary" : "btn-ghost-glass"
                }`}
              >
                {s === 0 ? "Off" : `${s}s`}
              </button>
            ))}
          </div>
        </Row>
      </div>
    </main>
  );
}

function Row({ label, desc, children }: { label: string; desc: string; children: React.ReactNode }) {
  return (
    <div className="glass flex flex-wrap items-center justify-between gap-3 rounded-2xl p-4">
      <div>
        <div className="font-semibold">{label}</div>
        <div className="text-sm text-muted-foreground">{desc}</div>
      </div>
      {children}
    </div>
  );
}

function Toggle({ on, onChange }: { on: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!on)}
      role="switch"
      aria-checked={on}
      className={`relative h-7 w-12 rounded-full transition ${on ? "bg-[var(--color-primary)]" : "bg-white/15"}`}
    >
      <span className={`absolute top-0.5 left-0.5 size-6 rounded-full bg-white transition ${on ? "translate-x-5" : ""}`} />
    </button>
  );
}

function About({ onBack }: { onBack: () => void }) {
  return (
    <main className="relative z-10 mx-auto max-w-2xl px-4 py-10">
      <button onClick={onBack} className="btn-ghost-glass mb-6 rounded-full px-4 py-2 text-sm">← Back</button>
      <h2 className="text-4xl font-black gradient-text">About Nova TTT</h2>
      <div className="glass mt-6 space-y-4 rounded-2xl p-6 text-muted-foreground">
        <p>
          Nova TicTacToe is a love letter to a timeless game. Built with React and crafted with a premium glassmorphism aesthetic, it works offline, on any device, with no ads and no accounts.
        </p>
        <p>
          The hard AI uses the classic Minimax algorithm — it cannot be beaten. The best you can hope for is a draw. Try medium for a fair fight, or easy to teach a kid.
        </p>
        <p className="text-sm">Keyboard shortcuts: <kbd className="rounded bg-white/10 px-1">1–9</kbd> to play, <kbd className="rounded bg-white/10 px-1">R</kbd> to restart.</p>
      </div>
    </main>
  );
}

function Footer() {
  return (
    <footer className="relative z-10 mx-auto max-w-6xl px-4 pb-8 pt-6">
      <div className="glass flex flex-wrap items-center justify-between gap-4 rounded-2xl px-5 py-4 text-sm text-muted-foreground">
        <div>© {new Date().getFullYear()} Nova TicTacToe. Crafted with care.</div>
        <div className="flex items-center gap-3">
          {[
            { l: "Twitter", h: "#" },
            { l: "GitHub", h: "#" },
            { l: "Dribbble", h: "#" },
          ].map((s) => (
            <a key={s.l} href={s.h} className="hover:text-foreground transition" aria-label={s.l}>{s.l}</a>
          ))}
        </div>
      </div>
    </footer>
  );
}
